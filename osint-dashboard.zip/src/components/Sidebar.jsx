export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-800 p-4 overflow-y-auto">
      <h2 className="text-lg font-semibold mb-4">Assets</h2>
      <ul>
        <li className="mb-2">🟠 Peeragarhi_PRG - High</li>
        <li className="mb-2">🟡 Rohinihub_DEL - Medium</li>
      </ul>
    </div>
  )
}
