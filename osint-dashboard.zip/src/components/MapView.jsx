import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

export default function MapView() {
  return (
    <div className="flex-1">
      <MapContainer center={[22.9734, 78.6569]} zoom={5} className="w-full h-full">
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        <Marker position={[28.7041, 77.1025]}>
          <Popup>Incident in Delhi</Popup>
        </Marker>
      </MapContainer>
    </div>
  )
}
