export default function NewsFeed() {
  return (
    <div className="w-96 bg-gray-800 p-4 overflow-y-auto">
      <h2 className="text-lg font-semibold mb-4">Live Events</h2>
      <div>
        <p className="text-sm mb-2">
          🚨 Clash Over Money - Madhugadhi, UP
          <br /><span className="text-gray-400">21st Jun, 5:21 AM</span>
        </p>
        <p className="text-sm mb-2">
          ⚔️ Woman Attacked - Bulandshahr, UP
          <br /><span className="text-gray-400">21st Jun, 5:21 AM</span>
        </p>
      </div>
    </div>
  )
}
