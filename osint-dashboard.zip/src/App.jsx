import MapView from './components/MapView'
import Sidebar from './components/Sidebar'
import NewsFeed from './components/NewsFeed'

export default function App() {
  return (
    <div className="flex h-screen bg-gray-900 text-white">
      <Sidebar />
      <MapView />
      <NewsFeed />
    </div>
  )
}
